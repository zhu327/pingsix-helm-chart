#
# Licensed to the Apache Software Foundation (ASF) under one or more
# contributor license agreements.  See the NOTICE file distributed with
# this work for additional information regarding copyright ownership.
# The ASF licenses this file to You under the Apache License, Version 2.0
# (the "License"); you may not use this file except in compliance with
# the License.  You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

{{/*
Expand the name of the chart.
*/}}
{{- define "apisix-ingress-controller-manager.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}
{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "apisix-ingress-controller-manager.name.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}
{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "apisix-ingress-controller-manager.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}
{{/*
Common labels
*/}}
{{- define "apisix-ingress-controller-manager.labels" -}}
helm.sh/chart: {{ include "apisix-ingress-controller-manager.chart" . }}
{{ include "apisix-ingress-controller-manager.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "apisix-ingress-controller-manager.selectorLabels" -}}
{{- if .Values.labelsOverride }}
{{- tpl (.Values.labelsOverride | toYaml) . }}
{{- else }}
app.kubernetes.io/name: {{ include "apisix-ingress-controller-manager.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}
{{- end }}

{{/*
Webhook service name - ensure it stays within 63 character limit
*/}}
{{- define "apisix-ingress-controller-manager.webhook.serviceName" -}}
{{- $suffix := "-webhook-svc" -}}
{{- $maxLen := sub 63 (len $suffix) | int -}}
{{- $baseName := include "apisix-ingress-controller-manager.name.fullname" . | trunc $maxLen | trimSuffix "-" -}}
{{- printf "%s%s" $baseName $suffix -}}
{{- end }}

{{/*
Webhook secret name - ensure it stays within 63 character limit
*/}}
{{- define "apisix-ingress-controller-manager.webhook.secretName" -}}
{{- $suffix := "-webhook-cert" -}}
{{- $maxLen := sub 63 (len $suffix) | int -}}
{{- $baseName := include "apisix-ingress-controller-manager.name.fullname" . | trunc $maxLen | trimSuffix "-" -}}
{{- printf "%s%s" $baseName $suffix -}}
{{- end }}

{{/*
Etcd-adapter Service name. Only the leader pod with
ingress.pingsix.io/etcd-serving=true is selected by this Service.
*/}}
{{- define "apisix-ingress-controller-manager.etcd.serviceName" -}}
{{- $suffix := "-etcd" -}}
{{- $maxLen := sub 63 (len $suffix) | int -}}
{{- $baseName := include "apisix-ingress-controller-manager.name.fullname" . | trunc $maxLen | trimSuffix "-" -}}
{{- printf "%s%s" $baseName $suffix -}}
{{- end }}
